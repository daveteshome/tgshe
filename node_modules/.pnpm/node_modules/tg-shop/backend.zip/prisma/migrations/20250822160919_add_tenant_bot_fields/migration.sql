-- AlterTable
ALTER TABLE "public"."Tenant" ADD COLUMN     "botToken" TEXT,
ADD COLUMN     "botUsername" TEXT,
ADD COLUMN     "postChatId" TEXT;
