// apps/backend/src/api/products.ts
import { Router } from "express";
import { Readable } from "node:stream";
import { db } from "../lib/db";
import { requireTenant } from "./_helpers";

export const productsRouter = Router();

const BOT_TOKEN = process.env.BOT_TOKEN || "";

productsRouter.get("/:id/image", async (req, res, next) => {
  try {
    const tenantId = requireTenant(req);
    const id = req.params.id;

    const p = await db.product.findFirst({
      where: { id, tenantId },
      include: { images: { orderBy: { position: "asc" }, take: 1 } },
    });

    const ref = p?.images?.[0]?.url;
    if (!ref) return res.status(404).end();

    // Public URL? just redirect
    if (/^https?:\/\//i.test(ref)) return res.redirect(ref);

    // Telegram file_id?
    const m = /^tg:file_id:(.+)$/i.exec(ref);
    if (!m) return res.status(400).send("Unsupported image reference");
    if (!BOT_TOKEN) return res.status(500).send("BOT_TOKEN not configured");

    const fileId = m[1];

    // 1) Resolve file_id -> file_path
    const gf = await fetch(
      `https://api.telegram.org/bot${BOT_TOKEN}/getFile?file_id=${encodeURIComponent(fileId)}`
    ).then(r => r.json());

    const path = gf?.result?.file_path;
    if (!path) return res.status(404).send("File not found on Telegram");

    // 2) Fetch file
    const tgResp = await fetch(`https://api.telegram.org/file/bot${BOT_TOKEN}/${path}`);
    if (!tgResp.ok) return res.status(502).send("Failed to fetch file");

    res.setHeader("Cache-Control", "public, max-age=3600");
    res.setHeader("Content-Type", tgResp.headers.get("content-type") ?? "application/octet-stream");

    // Web ReadableStream -> Node stream
    const body: any = tgResp.body;
    if (body && typeof (Readable as any).fromWeb === "function") {
      return (Readable as any).fromWeb(body).pipe(res);
    }

    // Fallback: buffer
    const buf = Buffer.from(await tgResp.arrayBuffer());
    res.setHeader("Content-Length", String(buf.length));
    res.end(buf);
  } catch (e) { next(e); }
});

export default productsRouter;
