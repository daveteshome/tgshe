import { S3Client, PutObjectCommand, HeadObjectCommand } from "@aws-sdk/client-s3";
import crypto from "node:crypto";
import { imageSize } from "image-size";
import { db } from "./db";
import { ENV } from '../config/env';

// Example: ENV.R2_PUBLIC_BASE could be like
//   https://pub-xxxx.r2.dev   (dev)
// or https://cdn.yourdomain.com (prod with custom domain)
export function publicImageUrl(imageId: string): string {
  // Your upload code puts the original object at /images/<imageId>/orig
  // If you store variants, keep the path consistent ("orig" is what you showed)
  const base = ENV.R2_PUBLIC_HOST.replace(/\/+$/, '');
  return `${base}/images/${imageId}/orig`;
}


const s3 = new S3Client({
  region: "auto",
  endpoint: process.env.R2_ENDPOINT!,
  credentials: {
    accessKeyId: process.env.R2_ACCESS_KEY_ID!,
    secretAccessKey: process.env.R2_SECRET_ACCESS_KEY!,
  },
});

export async function upsertImageFromBytes(
  bytes: Buffer,
  mime: string,
  tenantId?: string
) {
  const sha256 = crypto.createHash("sha256").update(bytes).digest("hex");
  const bucket = process.env.R2_BUCKET!;
  const base = `images/${sha256}`;
  const key = `${base}/orig`;

  // If already exists, skip upload
  try {
    await s3.send(new HeadObjectCommand({ Bucket: bucket, Key: key }));
  } catch {
    await s3.send(new PutObjectCommand({
      Bucket: bucket,
      Key: key,
      Body: bytes,
      ContentType: mime,
      CacheControl: "public, max-age=31536000, immutable",
    }));
  }

  // dimensions
  const dim = imageSize(bytes);
  const width = dim.width ?? 0;
  const height = dim.height ?? 0;

  // Upsert DB record
  const img = await db.image.upsert({
    where: { sha256 },
    update: { width, height, mime, tenantId },
    create: { sha256, bucketKeyBase: base, width, height, mime, tenantId },
  });

  return img; // { id, bucketKeyBase, ... }
}
