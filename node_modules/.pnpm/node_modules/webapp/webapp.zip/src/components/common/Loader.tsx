import React from "react";
export const Loader = () => <div style={{ opacity: 0.7 }}>Loading…</div>;